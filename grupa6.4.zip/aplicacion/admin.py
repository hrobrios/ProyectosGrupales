from django.contrib import admin
from .models import Club, Jugador

# Register your models here.
admin.site.register(Club)
admin.site.register(Jugador)
